import { useState } from "react";
import {
  MoonStar, House, Sun, Orbit, HeartHandshake, CalendarDays,
  Sparkles, Menu, ChevronRight, Stars, Clock3, MapPin, UserRound,
  CircleHelp, ShieldCheck
} from "lucide-react";

const signs = [
  ["Aries","♈","Mar 21 – Apr 19"],["Taurus","♉","Apr 20 – May 20"],
  ["Gemini","♊","May 21 – Jun 20"],["Cancer","♋","Jun 21 – Jul 22"],
  ["Leo","♌","Jul 23 – Aug 22"],["Virgo","♍","Aug 23 – Sep 22"],
  ["Libra","♎","Sep 23 – Oct 22"],["Scorpio","♏","Oct 23 – Nov 21"],
  ["Sagittarius","♐","Nov 22 – Dec 21"],["Capricorn","♑","Dec 22 – Jan 19"],
  ["Aquarius","♒","Jan 20 – Feb 18"],["Pisces","♓","Feb 19 – Mar 20"]
];

const demoHoroscope = "This is sample preview text. Once the astrology calculation and interpretation services are connected, this section will show a month-specific reading based on the selected sign and the chosen Vedic astrology conventions.";

const nav = [
  ["Home",House],["Monthly Horoscope",Sun],["Kundli",Orbit],
  ["Kundli Milan",HeartHandshake],["Sade Sati",MoonStar],
  ["Dhaiya",CalendarDays]
];

function App() {
  const [page,setPage] = useState("Home");
  const [sign,setSign] = useState("Aries");
  const [mobileOpen,setMobileOpen] = useState(false);
  const [notice,setNotice] = useState("");

  const choosePage = (name) => { setPage(name); setMobileOpen(false); setNotice(""); };

  return <div className="app-shell">
    <aside className={`sidebar ${mobileOpen ? "open" : ""}`}>
      <div className="brand"><div className="brand-mark"><MoonStar size={23}/></div><div><b>AstroKundli</b><small>VEDIC ASTROLOGY</small></div></div>
      <div className="side-label">WORKSPACE</div>
      <nav>{nav.map(([name,Icon])=><button key={name} className={`nav-item ${page===name?"active":""}`} onClick={()=>choosePage(name)}><Icon size={18}/><span>{name}</span>{page===name&&<ChevronRight size={16} className="nav-arrow"/>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="help-icon"><CircleHelp size={18}/></div><div><b>AstroKundli Preview</b><small>Starter version · 0.1</small></div></div>
    </aside>

    <main className="main">
      <header className="topbar">
        <button className="mobile-menu" onClick={()=>setMobileOpen(!mobileOpen)} aria-label="Toggle menu"><Menu/></button>
        <div className="crumb">AstroKundli <span>/</span> {page}</div>
        <div className="top-actions"><span className="today"><CalendarDays size={15}/> November 2026</span><div className="avatar"><UserRound size={17}/></div></div>
      </header>

      <div className="content">
        {page==="Home" && <Home setPage={choosePage} sign={sign} setSign={setSign}/>}
        {page==="Monthly Horoscope" && <Horoscope sign={sign} setSign={setSign}/>}
        {page==="Kundli" && <Kundli setNotice={setNotice}/>}
        {page==="Kundli Milan" && <Milan setNotice={setNotice}/>}
        {page==="Sade Sati" && <Transit title="Sade Sati" subtitle="Explore Saturn's seven-and-a-half-year transit relative to the natal Moon sign."/>}
        {page==="Dhaiya" && <Transit title="Dhaiya" subtitle="Explore the two-and-a-half-year Saturn transit periods relative to the natal Moon sign."/>}
        {notice && <div className="notice"><ShieldCheck size={17}/>{notice}</div>}
        <footer>AstroKundli · Astrology is a traditional belief system, not a scientifically established method of prediction.</footer>
      </div>
    </main>
  </div>;
}

function PageHeading({eyebrow,title,subtitle}) {
  return <div className="page-heading"><div className="eyebrow"><Sparkles size={14}/>{eyebrow}</div><h1>{title}</h1><p>{subtitle}</p></div>;
}

function Home({setPage,sign,setSign}) {
  return <>
    <section className="hero">
      <div className="hero-copy"><div className="eyebrow gold"><Stars size={14}/> YOUR VEDIC ASTROLOGY COMPANION</div><h1>Discover your<br/><em>cosmic path.</em></h1><p>Explore your horoscope, birth chart and planetary cycles — all in one place.</p><button className="primary-btn" onClick={()=>setPage("Kundli")}>Create your Kundli <ChevronRight size={17}/></button></div>
      <div className="orbital-art"><div className="orbit orbit-one"></div><div className="orbit orbit-two"></div><div className="planet">☾</div><span className="star s1">✦</span><span className="star s2">✧</span><span className="star s3">✦</span><span className="zodiac z1">♈</span><span className="zodiac z2">♌</span><span className="zodiac z3">♎</span><span className="zodiac z4">♑</span></div>
    </section>
    <div className="section-title"><div><h2>Your astrology tools</h2><p>Choose a section to get started.</p></div></div>
    <div className="feature-grid">
      {[
        ["Monthly Horoscope","Read monthly insights for all 12 signs.","sun","Monthly Horoscope"],
        ["Birth Kundli","Explore your Vedic birth chart.","orbit","Kundli"],
        ["Kundli Milan","Compare two birth charts.","heart","Kundli Milan"],
        ["Sade Sati","Check Saturn's seven-and-a-half-year cycle.","moon","Sade Sati"],
        ["Dhaiya","Explore Saturn's Dhaiya periods.","calendar","Dhaiya"]
      ].map(([title,desc,icon,target])=><button className="feature-card" key={title} onClick={()=>setPage(target)}><div className="feature-icon">{icon==="sun"?<Sun/>:icon==="orbit"?<Orbit/>:icon==="heart"?<HeartHandshake/>:icon==="moon"?<MoonStar/>:<CalendarDays/>}</div><div><h3>{title}</h3><p>{desc}</p></div><ChevronRight className="feature-arrow" size={18}/></button>)}
    </div>
    <section className="sign-panel"><div className="section-title"><div><h2>Choose your zodiac sign</h2><p>Preview the monthly horoscope section.</p></div></div><div className="sign-grid">{signs.map(([name,symbol])=><button key={name} className={`sign-tile ${sign===name?"selected":""}`} onClick={()=>setSign(name)}><span>{symbol}</span><b>{name}</b></button>)}</div><button className="text-btn" onClick={()=>setPage("Monthly Horoscope")}>View {sign} horoscope <ChevronRight size={16}/></button></section>
  </>;
}

function Horoscope({sign,setSign}) {
  return <>
    <PageHeading eyebrow="MONTHLY GUIDANCE" title="Monthly Horoscope" subtitle="Explore the month ahead for each zodiac sign."/>
    <div className="panel">
      <label className="field-label">SELECT ZODIAC SIGN</label>
      <div className="sign-select">{signs.map(([name,symbol])=><button key={name} className={sign===name?"chosen":""} onClick={()=>setSign(name)}>{symbol} {name}</button>)}</div>
      <div className="reading"><div className="reading-symbol">{signs.find(s=>s[0]===sign)?.[1]}</div><div><div className="eyebrow">NOVEMBER 2026 · DEMO PREVIEW</div><h2>{sign} Monthly Horoscope</h2><p>{demoHoroscope}</p></div></div>
      <div className="demo-tag">Sample content — real transit-based readings are not connected yet.</div>
    </div>
  </>;
}

function Kundli({setNotice}) {
  return <>
    <PageHeading eyebrow="BIRTH CHART" title="Generate your Kundli" subtitle="Enter birth details to prepare the information needed for a Vedic birth chart."/>
    <div className="form-panel"><div className="form-grid">
      <div className="field full"><label>FULL NAME</label><input placeholder="Enter name (optional)"/></div>
      <div className="field"><label>DATE OF BIRTH</label><input type="date"/></div>
      <div className="field"><label>TIME OF BIRTH</label><input type="time"/></div>
      <div className="field full"><label>PLACE OF BIRTH</label><input placeholder="City, state, country"/><small><MapPin size={13}/> Use the birthplace, not your current location.</small></div>
    </div><button className="primary-btn" onClick={()=>setNotice("Birth chart calculation is not connected in this starter. No chart has been calculated or saved.")}>Prepare birth chart <ChevronRight size={17}/></button></div>
    <div className="info-card"><ShieldCheck/><p>Birth time and place affect chart calculations. This starter does not send or store the details you enter.</p></div>
  </>;
}

function Milan({setNotice}) {
  return <>
    <PageHeading eyebrow="COMPATIBILITY" title="Kundli Milan" subtitle="Enter both people's birth details for Ashtakoota matching."/>
    <div className="two-forms"><BirthForm title="Person 1" /><BirthForm title="Person 2" /></div>
    <button className="primary-btn" onClick={()=>setNotice("The 36-Gun Ashtakoota calculation engine is not connected yet. No compatibility score has been generated.")}>Compare Kundlis <HeartHandshake size={17}/></button>
    <div className="info-card"><ShieldCheck/><p>Traditional matching uses birth-chart factors such as Moon sign and Nakshatra. A real score requires validated chart calculations.</p></div>
  </>;
}

function BirthForm({title}) {
  return <div className="form-panel"><h3>{title}</h3><div className="form-grid"><div className="field full"><label>NAME (OPTIONAL)</label><input placeholder="Name"/></div><div className="field full"><label>DATE OF BIRTH</label><input type="date"/></div><div className="field full"><label>TIME OF BIRTH</label><input type="time"/></div><div className="field full"><label>PLACE OF BIRTH</label><input placeholder="City, state, country"/></div></div></div>;
}

function Transit({title,subtitle}) {
  return <>
    <PageHeading eyebrow="SATURN TRANSIT TRACKER" title={title} subtitle={subtitle}/>
    <div className="panel transit-panel"><div className="saturn">♄</div><div><div className="eyebrow">CALCULATION MODULE · COMING NEXT</div><h2>{title} date calculator</h2><p>Choose a natal Moon sign after the ephemeris engine is connected. The app will then calculate Saturn's sign ingress and egress dates, including retrograde re-entries, using the selected Vedic settings.</p></div></div>
    <div className="notice"><Clock3 size={17}/> Exact dates are not displayed until an ephemeris-based calculation engine is integrated and tested.</div>
  </>;
}

export default App;